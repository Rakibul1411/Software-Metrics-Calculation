public class Alpha {
    public String toString() {
	return "alpha";
    }
}
