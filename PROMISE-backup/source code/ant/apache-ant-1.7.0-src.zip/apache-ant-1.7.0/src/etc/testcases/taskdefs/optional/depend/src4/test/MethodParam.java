package test;

public class MethodParam {
    void method1() {
        System.out.print(ContainsOnlyInner.class);
    }
}

