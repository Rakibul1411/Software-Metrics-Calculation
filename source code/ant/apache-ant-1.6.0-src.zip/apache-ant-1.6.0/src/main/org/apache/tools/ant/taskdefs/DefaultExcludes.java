/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Ant" and "Apache Software
 *    Foundation" must not be used to endorse or promote products derived
 *    from this software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache"
 *    nor may "Apache" appear in their names without prior written
 *    permission of the Apache Group.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package org.apache.tools.ant.taskdefs;

import org.apache.tools.ant.Task;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;

/**
 * Alters the default excludes for the <strong>entire</strong> build..
 *
 * @author Gus Heck &lt;gus.heck@olin.edu&gt;
 *
 * @since Ant 1.6
 *
 * @ant.task category="utility"
 */
public class DefaultExcludes extends Task {
    private String add = "";
    private String remove = "";
    private boolean defaultrequested = false;
    private boolean echo = false;

    // by default, messages are always displayed
    private int logLevel = Project.MSG_WARN;

    /**
     * Does the work.
     *
     * @exception BuildException if something goes wrong with the build
     */
    public void execute() throws BuildException {
        if (!defaultrequested && add.equals("") && remove.equals("") && !echo) {
            throw new BuildException("<defaultexcludes> task must set "
                + "at least one attribute (echo=\"false\""
                + " doesn't count since that is the default");
        }
        if (defaultrequested) {
            DirectoryScanner.resetDefaultExcludes();
        }
        if (!add.equals("")) {
            DirectoryScanner.addDefaultExclude(add);
        }
        if (!remove.equals("")) {
            DirectoryScanner.removeDefaultExclude(remove);
        }
        if (echo) {
            StringBuffer message
                = new StringBuffer("Current Default Excludes:\n");
            String[] excludes = DirectoryScanner.getDefaultExcludes();
            for (int i = 0; i < excludes.length; i++) {
                message.append("  " + excludes[i] + "\n");
            }
            log(message.toString(), logLevel);
        }
    }

    /**
     * go back to standard default patterns
     *
     * @param def if true go back to default patterns
     */
    public void setDefault(boolean def) {
        defaultrequested = def;
    }
    /**
     * Pattern to add to the default excludes
     *
     * @param add Sets the value for the pattern to exclude.
     */
    public void setAdd(String add) {
        this.add = add;
    }

     /**
     * Pattern to remove from the default excludes.
     *
     * @param remove Sets the value for the pattern that
     *            should no longer be excluded.
     */
    public void setRemove(String remove) {
        this.remove = remove;
    }

    /**
     * If true, echo the default excludes.
     *
     * @param echo whether or not to echo the contents of
     *             the default excludes.
     */
    public void setEcho(boolean echo) {
        this.echo = echo;
    }


}
