/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Ant" and "Apache Software
 *    Foundation" must not be used to endorse or promote products derived
 *    from this software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache"
 *    nor may "Apache" appear in their names without prior written
 *    permission of the Apache Group.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package org.apache.tools.ant.taskdefs.optional.ide;

/**
 * Super class for all VAJ tasks. Contains common
 * attributes (remoteServer) and util methods
 *
 * @author: Wolf Siberski
 * @author: Martin Landers, Beck et al. projects
 */
import org.apache.tools.ant.Task;


public class VAJTask extends Task {
    /**
     * Adaption of VAJLocalUtil to Task context.
     */
    class VAJLocalToolUtil extends VAJLocalUtil {
        public void log(String msg, int level) {
            VAJTask.this.log(msg, level);
        }
    }

    // server name / port of VAJ remote tool api server
    protected String remoteServer = null;

    // holds the appropriate VAJUtil implementation
    private VAJUtil util = null;

    // checks if this task throws BuildException on error
    protected boolean haltOnError = true;

    /**
     * returns the VAJUtil implementation
     */
    protected VAJUtil getUtil() {
        if (util == null) {
            if (remoteServer == null) {
                util = new VAJLocalToolUtil();
            } else {
                util = new VAJRemoteUtil(this, remoteServer);
            }
        }
        return util;
    }

    /**
     * Name and port of a remote tool server, optiona.
     * Format: &lt;servername&gt;:&lt;port no&gt;.
     * If this attribute is set, the tasks will be executed on the specified tool
     * server.
     */
    public void setRemote(String remoteServer) {
        this.remoteServer = remoteServer;
    }

    /**
    * Flag to control behaviour in case of VAJ errors.
    * If this attribute is set errors will be ignored
    * (no BuildException will be thrown) otherwise
    * VAJ errors will be wrapped into a BuildException and
    * stop the build.
    */
    public void setHaltonerror(boolean newHaltOnError) {
        haltOnError = newHaltOnError;
    }
}
