/*
 * Copyright 2001-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * $Id: Node.java,v 1.3 2004/02/16 22:55:54 minchau Exp $
 */

package org.apache.xalan.xsltc.runtime;

/**
 * This class is used as "wrapper" for dom nodes. Wrappers are needed when
 * a node is passed as a parameter to a template.
 * @author Jacek Ambroziak
 * @author Santiago Pericas-Geertsen
 */
public class Node {
    public int node;
    public int type;
	
    public Node(int n, int t) {
	node = n;
	type = t;
    }
}
